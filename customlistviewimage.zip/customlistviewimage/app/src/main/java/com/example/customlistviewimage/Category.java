package com.example.customlistviewimage;

public class Category {
    private int index;
    private int category;
    private int action;

    public int getIndex() {

        return index;
    }

    public void setIndex(int index) {

        this.index = index;
    }

    public int getCategory(){

        return category;
    }

    public void setCategory(int category){

        this.category = category;
    }

    public int getAction() {

        return action;
    }

    public void setAction(int action) {

        this.action = action;
    }

}